<!DOCTYPE html>
<html>
	<head>
	<link href="<?php echo base_url(); ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>assets/plugins/switchery/dist/switchery.min.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>assets/plugins/multiselect/css/multi-select.css"  rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/plugins/select2/select2.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/plugins/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>assets/plugins/mjolnic-bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/plugins/sweetalert/dist/sweetalert.css" rel="stylesheet" type="text/css">
	<link href="//cdn.rawgit.com/noelboss/featherlight/1.6.1/release/featherlight.min.css" type="text/css" rel="stylesheet" />
	<?php $this->load->view('head', $header_data); ?>

	<style type="text/css">
	.tab-content {
	    width: 100%;
	}
	</style>
	</head>

	<body class="fixed-left">
		<?php $this->load->view('header'); ?>

		<div class="content-page">
			<div class="content">
				<div class="container">

					<div id="modal-processing" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-body">
                                	<p class="text-center"><i class="fa fa-refresh fa-5x fa-spin"></i></p>
		                            <p class="text-center">Processing...</p>
                                </div>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->

					<!-- Page-Title -->
					<div class="row">
						<div class="col-sm-12">
							<h4 class="page-title"><?php echo $header_data['title']; ?></h4>
							<ol class="breadcrumb">
								<?php foreach ($bcrn as $title => $link): ?>
								<?php if (end($bcrn) != $link): ?>
								<li>
									<a href="<?php echo $link; ?>"><?php echo $title; ?></a>
								</li>
								<?php else: ?>
								<li class="active">
									<?php echo $title; ?>
								</li>
								<?php endif; ?>
								<?php endforeach; ?>
							</ol>
						</div>
					</div>
					<?php if (isset($msg)): ?>
					<div class="alert alert-info alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $msg; ?>
					</div>
					<?php endif; ?>
					<form role="form" method="post" enctype="multipart/form-data">
					<div class="row">
						<div class="col-sm-12">
							<div class="card-box">
								<!-- <div class="pull-right">
									<a href="<?php echo base_url(); ?>product/add_product" class="btn btn-primary" style="margin-bottom: 20px;"><i class="fa fa-plus"></i> Add New</a>
								</div>
								<div class="clearfix"></div> -->
								
								<div class="row">
									<div class="col-md-12">
										<h4 class="m-t-0 header-title"><b>Admin Account</b></h4>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Email</label>
											<input type="email" class="form-control" name="email" value="<?php echo isset($a3m_data['email']) ? $a3m_data['email'] : null; ?>" <?php echo $action == 'add' ? 'required' : 'readonly' ?>>
											<div id="email-alert" class="alert alert-danger" role="alert" style="display: none;">Email Invalid/Existed.</div>
										</div>
										<div class="form-group">
											<label>Username</label>
											<input type="text" class="form-control" name="username" value="<?php echo isset($a3m_data['username']) ? $a3m_data['username'] : null; ?>" <?php echo $action == 'add' ? 'required' : 'readonly' ?>>
										</div>
										<div class="form-group">
											<label>Division</label>
											<select class="form-control" name="division_id">
												<option value="0" <?php echo isset($a3m_data['division_id']) && $a3m_data['division_id'] == '0' ? 'selected' : null; ?>>Admin</option>
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Password</label>
											<input type="password" class="form-control" name="password" <?php echo $action == 'add' ? 'required' : null ?>>
										</div>
										<div class="form-group">
											<label>Confirm Password</label>
											<input type="password" class="form-control" name="confirm_password" <?php echo $action == 'add' ? 'required' : null ?>>
											<div id="password-alert" class="alert alert-danger" role="alert" style="display: none;">Passwords do not match. Please try again.</div>
										</div>
										<div class="form-group">
											<label>Status</label>
											<select class="form-control" name="status">
												<option value="Active" <?php echo isset($a3m_data['status']) && $a3m_data['status'] == 'Active' ? 'selected' : null; ?>>Active</option>
												<option value="Pending" <?php echo isset($a3m_data['status']) && $a3m_data['status'] == 'Pending' ? 'selected' : null; ?>>Pending</option>
												<option value="Banned" <?php echo isset($a3m_data['status']) && $a3m_data['status'] == 'Banned' ? 'selected' : null; ?>>Banned</option>
											</select>
										</div>
									</div>
									
								</div>
							</div>
							
							<div class="card-box">
								<div class="row">
									<div class="col-md-12 text-center">
										<button class="btn btn-primary waves-effect waves-light center-block" type="submit">Save</button>
									</div>
								</div>
							</div>
						</div>
					</div>
					</form>
					<!-- end row -->
				</div> <!-- container -->
			</div> <!-- content -->
			<?php $this->load->view('footer'); ?>
		</div>
		<?php $this->load->view('foot'); ?>
		<script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js" type="text/javascript"></script>
		<script src="<?php echo base_url(); ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/switchery/dist/switchery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/multiselect/js/jquery.multi-select.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery-quicksearch/jquery.quicksearch.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/select2/select2.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/bootstrap-filestyle/src/bootstrap-filestyle.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/interactjs/interact.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/mjolnic-bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/tinymce/tinymce.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
        <script src="//cdn.jsdelivr.net/jquery.loadingoverlay/latest/loadingoverlay.min.js"></script>
        <script src="//cdn.jsdelivr.net/jquery.loadingoverlay/latest/loadingoverlay_progress.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/sweetalert/dist/sweetalert.min.js"></script>
        <script src="//cdn.rawgit.com/noelboss/featherlight/1.6.1/release/featherlight.min.js" type="text/javascript" charset="utf-8"></script>
		<script type="text/javascript">
		$(document).ready(function() {
			$('.select2').select2();

			$('.datepicker-till-today').datepicker({
				format: 'yyyy-mm-dd',
				endDate : moment().format('YYYY-MM-DD')
			});

	        <?php if ($action == 'add'): ?>
	        $('input[name=email]').blur(function() {
				if ($(this).val()) {
					$.ajax({
						url: '<?php echo base_url(); ?>management/a3m_email_check_ajax',
						data: {
							email: $(this).val()
						},
						method: 'POST'
					}).done(function(data) {
						data = JSON.parse(data);
						if (data.code != 200) {
							$('#email-alert').html(data.msg);
							$('#email-alert').show();
							$('input[name=email]').parent().addClass('has-error');
						} else {
							$('#email-alert').hide();
							$('input[name=email]').parent().removeClass('has-error');
						}
					});
				} else {
					$('#email-alert').hide();
					$('input[name=email]').parent().removeClass('has-error');
				}
			});
	        <?php endif; ?>

	        $('input[name=password], input[name=confirm_password]').keyup(function() {
				if ($('input[name=confirm_password]').val()) {
					if ($('input[name=password]').val() != $('input[name=confirm_password]').val()) {
						$('#password-alert').show();
						$('input[name=confirm_password]').parent().addClass('has-error');
					} else {
						$('#password-alert').hide();
						$('input[name=confirm_password]').parent().removeClass('has-error');
					}
				}
			});
		});
		</script>
	</body>
</html>