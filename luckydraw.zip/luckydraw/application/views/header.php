<!-- Begin page -->
<div id="wrapper">
	<!-- Top Bar Start -->
	<div class="topbar">
		<!-- LOGO -->
		<div class="topbar-left">
			<div class="text-center">
				<a href="<?php echo base_url(); ?>" class="logo"><i class="icon-magnet icon-c-logo"></i><span>Lucky Draw</span></a>
				<!-- /<img src="http://localhost/ci_test//assets/images/logo.png"> -->
			</div>
		</div>
		<!-- Button mobile view to collapse sidebar menu -->
		<div class="navbar navbar-default" role="navigation">
			<div class="container" style="background:#000;">
				<div class="">
					<div class="pull-left">
						<button class="button-menu-mobile open-left">
						<i class="ion-navicon"></i>
						</button>
						<span class="clearfix"></span>
					</div>
					<ul class="nav navbar-nav navbar-right pull-right">
						<li class="hidden-xs">
							<a href="#" id="btn-fullscreen" class="waves-effect waves-light"><i class="icon-size-fullscreen"></i></a>
						</li>
						<li class="dropdown">
							<a href="" class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-user"></i> </a>
							<ul class="dropdown-menu">
								<!-- <li><a href="javascript:void(0)"><i class="ti-user m-r-5"></i> Profile</a></li> -->
								<li><a href="<?php echo base_url(); ?>management/logout"><i class="ti-power-off m-r-5"></i> Logout</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!--/.nav-collapse -->
			</div>
		</div>
	</div>
	<!-- Top Bar End -->
	<!-- ========== Left Sidebar Start ========== -->
	<div class="left side-menu">
		<div class="sidebar-inner slimscrollleft">
			<!--- Divider -->
			<div id="sidebar-menu">
				<ul>
					<li class="text-muted menu-title">Navigation</li>

					<?php if ($this->acl_role_model->has_role('Admin', $this->session->userdata('account_id'))): ?>
					<li class="text-muted menu-title">
						Welcome back, <span style="text-transform:lowercase;">Admin</span></a>
					</li>
					<?php endif; ?>
					<li>
						<a href="<?php echo base_url(); ?>management" class="waves-effect <?php echo $header_data['page'] == 'dashboard' ? 'active' : null; ?>"><i class="fa fa-home"></i><span> Dashboard</span></a>
					</li>
					<?php if ($this->acl_role_model->has_role('Admin', $this->session->userdata('account_id')) ): ?>
					<li class="has_sub">
						<a href="#" class="waves-effect <?php echo $header_data['page'] == 'consultant' ? 'active' : null; ?>"><i class="fa fa-user" aria-hidden="true"></i></i><span> Results </span> </a>
						<ul class="list-unstyled">
							
							<li class="<?php echo isset($header_data['sub_page']) && $header_data['sub_page'] == 'candidate_manager' ? 'active' : null; ?>"><a href="<?php echo base_url(); ?>result/manage_result">Results Menagement</a></li>
							
							
						</ul>
					</li>
					<?php endif; ?>
					
					<?php if ($this->acl_role_model->has_role('Admin', $this->session->userdata('account_id'))): ?>
					<li class="has_sub">
						<a href="#" class="waves-effect <?php echo $header_data['page'] == 'user' ? 'active' : null; ?>"><i class="fa fa-users" aria-hidden="true"></i></i> <span> User </span> </a>
						<ul class="list-unstyled">
							<?php if ($this->authorization->is_permitted('retrieve_consultants')): ?>
							<li class="<?php echo isset($header_data['sub_page']) && $header_data['sub_page'] == 'manage_user' ? 'active' : null; ?>"><a href="<?php echo base_url(); ?>user/manage_user">Manage Users</a></li>
							<?php endif; ?>
						</ul>
					</li>
					<?php endif; ?>
					
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- Left Sidebar End -->