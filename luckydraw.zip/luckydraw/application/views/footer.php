    <footer class="footer text-right">
        <?php echo date('Y'); ?> © Lucky Draw by Glynnis.
    </footer>
</div>
<!-- END wrapper -->