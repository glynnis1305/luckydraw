<!DOCTYPE html>
<html>
  <head>
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/datatables/1.10.10/css/dataTables.bootstrap.css" />
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/dataTable/lib/jquery.dataTables/css/DT_bootstrap.css" />
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/dataTable/css/datatables.responsive.css" />
  <link rel="stylesheet" href="//cdn.datatables.net/buttons/1.1.1/css/buttons.dataTables.min.css" />
  <link href="<?php echo base_url(); ?>assets/plugins/sweetalert/dist/sweetalert.css" rel="stylesheet" type="text/css">
  <?php $this->load->view('head', $header_data); ?>

  <style type="text/css">

  <?php if (count($color_code) > 0): ?>
  <?php foreach ($color_code as $index => $code_css): ?>
  .td-tracking-<?php echo $index; ?> {
    background-color: <?php echo $code_css; ?>;
    color: #FFF;
  }
  <?php endforeach; ?>
  <?php endif; ?>
  </style>
  </head>

  <body class="fixed-left">
    <?php $this->load->view('header'); ?>

    <div class="content-page">
      <div class="content">
        <div class="container">
          <!-- Page-Title -->
          <div class="row">
            <div class="col-sm-12">
              <h4 class="page-title"><?php echo $header_data['title']; ?></h4>
              <ol class="breadcrumb">
                <?php foreach ($bcrn as $title => $link): ?>
                <?php if (end($bcrn) != $link): ?>
                <li>
                  <a href="<?php echo $link; ?>"><?php echo $title; ?></a>
                </li>
                <?php else: ?>
                <li class="active">
                  <?php echo $title; ?>
                </li>
                <?php endif; ?>
                <?php endforeach; ?>
              </ol>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12">
              <div class="card-box">
                <?php if (isset($msg)): ?>
                <div class="alert alert-info">
                    <button data-dismiss="alert" class="close" type="button">×</button>
                    <?php echo $msg; ?>
                </div>
                <?php endif; ?>
                <h4>Please delete Results to redraw the lucky draw. </h4>
                <div class="pull-right">
                  <a href="<?php echo base_url(); ?>management/delete_draw" class="btn btn-primary waves-effect waves-light" style="margin-bottom: 20px;"><i class="fa fa-trash"></i> Delete</a>
                </div>
                <div class="clearfix"></div>
                <div class="row">
                  <!-- <div class="col-md-12 text-right">
                    <a href="<?php echo base_url(); ?>customer/create_customer" class="btn btn-primary waves-effect">
                      Add Member
                    </a>
                  </div> -->
                </div>
                <br/>
                <div class="table-responsive">
                  <table id="datatable-list" class="table table-striped table-bordered"></table>
                </div>
              </div>
            </div>
          </div>
          <!-- end row -->
        </div> <!-- container -->
      </div> <!-- content -->


      <?php $this->load->view('footer'); ?>
    </div>
    <?php $this->load->view('foot'); ?>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.16.0/moment.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/datatables/1.10.10/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/datatables/1.10.10/js/dataTables.bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
    var datatable_ajax_url = '<?php echo base_url().$datatable_ajax_url; ?>';

    var table = $('#datatable-list').DataTable({
      "colReorder": true,
      "buttons": ['excel', 'pdf', 'print'],
      "processing": true,
      "serverSide": true,
      "ajax": datatable_ajax_url,
      "columns": [
        <?php $order_columns = array(); ?>
        <?php if (isset($datatable_columns)): ?>
        <?php foreach ($datatable_columns as $index => $col): ?>
        {
          "data": '<?php echo $col['data']; ?>',
          "name": '<?php echo $col['name']; ?>',
          "title": '<?php echo $col['title']; ?>',
          "type": '<?php echo $col['type']; ?>',
          "orderable": <?php echo $col['orderable'] ? 'true' : 'false'; ?>,
          "searchable": <?php echo $col['searchable'] ? 'true' : 'false'; ?>,
          "visible": <?php echo isset($col['visible']) && !$col['visible'] ? 'false' : 'true'; ?>,
          "render": function (data, type, row, meta) {
            <?php echo (isset($col['render']) && !empty($col['render'])) ? $col['render'] : "return data;" ?>
          }
        }<?php echo ($col != end($datatable_columns)) ? ',' : null; ?>
        <?php if (isset($col['orderSequence']) && in_array($col['orderSequence'], array('asc', 'desc'))): ?>
        <?php $order_columns[] = array($index, $col['orderSequence']); ?>
        <?php endif; ?>
        <?php endforeach; ?>
        <?php endif; ?>
      ]
      <?php if (!empty($order_columns)): ?>
      ,"order": <?php echo json_encode($order_columns); ?>
      <?php endif; ?>
      <?php if (isset($datatable_createdrow)): ?>
      ,"createdRow": <?php echo $datatable_createdrow; ?>
      <?php endif; ?>
    });

    $(document).ready(function() {
      $('body').on('click', '.btn-delete', function (e) {
        // e.preventDefault();
        e.stopImmediatePropagation();
        var href = $(this).attr('href');
        swal({
          title: "Are you sure?",
          text: "This action will not be able to recover, proceed?",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Delete",
          closeOnConfirm: false
        },
        function(){
          window.location.href = href;
        });

        return false;
      });
    });
    </script>
  </body>
</html>