<!DOCTYPE html>
<html>
    <head>
    <?php $this->load->view('head', $header_data); ?>
    </head>

    <body class="fixed-left">
    	<?php $this->load->view('header'); ?>

    	<div class="content-page">
    		<div class="content">
				<div class="container">
					<!-- Page-Title -->
					<div class="row">
						<div class="col-sm-12">
							<h4 class="page-title">Dashboard</h4>
							<p class="text-muted page-title-alt">Welcome to <?php echo $header_data['website_title']; ?> admin panel.</p>
						</div>
					</div>
					
					<div class="row">
						<div class="col-lg-12">
							<div class="card-box">
								
								<h4 class="text-dark header-title m-t-0">Lucky Draw</h4>
								<form role="form" method="post" enctype="multipart/form-data">
									<input type="hidden" name="draw" value="draw"/>
									<button class="btn btn-primary waves-effect waves-light center-block" type="submit">Draw Winners</button>
								</form>
							</div>
						</div>
						<!-- end col -->
					</div>
					<!-- end row -->
				</div> <!-- container -->
			</div> <!-- content -->
    		<?php $this->load->view('footer'); ?>
    	</div>
    	<?php $this->load->view('foot'); ?>
    </body>
</html>