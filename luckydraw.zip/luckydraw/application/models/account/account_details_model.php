<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account_details_model extends CI_Model {

	/**
	 * Get details for all account
	 *
	 * @access public
	 * @return object details for all accounts
	 */
	function get()
	{
		return $this->db->get('a3m_account_details')->result();
	}

	/**
	 * Get account details by account_id
	 *
	 * @access public
	 * @param string $account_id
	 * @return object account details object
	 */
	function get_by_account_id($account_id)
	{
		return $this->db->get_where('a3m_account_details', array('account_id' => $account_id))->row();
	}

	// --------------------------------------------------------------------

	/**
	 * Update account details
	 *
	 * @access public
	 * @param int   $account_id
	 * @param array $attributes
	 * @return void
	 */
	function update($account_id, $attributes = array())
	{
		if (isset($attributes['division_id'])) if (strlen($attributes['division_id']) > 160) $attributes['division_id'] = substr($attributes['division_id'], 0, 160);

		// Update
		if ($this->get_by_account_id($account_id))
		{
			$this->db->where('account_id', $account_id);
			$this->db->update('a3m_account_details', $attributes);
		}
		// Insert
		else
		{
			$attributes['account_id'] = $account_id;
			$this->db->insert('a3m_account_details', $attributes);
		}
	}

}

/* End of file account_details_model.php */
/* Location: ./application/account/models/account_details_model.php */