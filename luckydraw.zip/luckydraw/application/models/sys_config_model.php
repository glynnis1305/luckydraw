<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class sys_config_model extends CI_Model {

	function get_field_value($field_key){
		$this->db->select('field_value');
		$this->db->from('ss_sys_config');
		$this->db->where('field_key', $field_key);

		$query = $this->db->get();

		if ($query->num_rows() > 0)
		{
		   $row = $query->row_array();
		   return $row['field_value'];
		}
		return false;
	}

	function get_sys_configs() {
		$this->db->select('*');
		$this->db->from('ss_sys_config');

		$query = $this->db->get();

		if ($query->num_rows() > 0)
		{
			$sys_configs = array();
			foreach ($query->result_array() as $row) {
				$sys_configs[$row['field_key']] = $row['field_value'];
			}
			return $sys_configs;
		}
		return false;
	}

	function save_settings($sys_configs) {
		foreach ($sys_configs as $key => $val) {
			$this->db->select('*');
			$this->db->from('ss_sys_config');
			$this->db->where('field_key', $key);

			$query = $this->db->get();

			$result = false;
			if ($query->num_rows() > 0)
			{
				$data = array('field_value' => $val);
				$this->db->where('field_key', $key);
				$this->db->update('ss_sys_config', $data);
			}
			else {
				$data = array('field_key' => $key, 'field_value' => $val);
				$this->db->insert('ss_sys_config', $data);
			}
		}
	}

	function save_setting ($key, $value) {
		$data = array('field_value' => $value);
		$this->db->where('field_key', $key);
		$this->db->update('ss_sys_config', $data);
	}
}


/* End of file sys_config_model.php */
/* Location: ./application/account/models/sys_config_model.php */