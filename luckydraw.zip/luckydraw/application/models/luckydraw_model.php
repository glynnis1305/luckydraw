<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class luckydraw_model extends CI_Model {
	public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();

        $CI =& get_instance();
        $CI->load->model(array(
        	'account/account_model',
        	'account/account_details_model',
        	'account/rel_account_role_model',
        	'sys_config_model'
        ));
		
		$this->account_model = $CI->account_model;
        $this->account_details_model = $CI->account_details_model;
        $this->rel_account_role_model = $CI->rel_account_role_model;
        $this->sys_config_model = $CI->sys_config_model;

        $CI->load->library(array(
        	'email'
        ));

        $this->email = $CI->email;
        $email_config['mailtype'] = 'html';
		$this->email->initialize($email_config);
    }

    function prize ($data) {

        $this->db->select('member_id, count(member_id) AS total');
        $this->db->from('winnings');
        $this->db->group_by('member_id');
        $this->db->having('count(member_id) = 5');

        $query = $this->db->get();

        $total_entry = $query->result_array();

        foreach ($query->result_array() as $total_entry)
            {
                $ids[] = $total_entry['member_id'];
            }

        $this->db->select('member_id, numbers');
        $this->db->from('winnings');
        $this->db->where_in('member_id',$ids);
        $this->db->order_by('rand()');
        $this->db->limit(1);

        $row = $this->db->get();

        $grandprize = $row->row_array();

        $this->db->insert('lucky_draw', array(
            'winning_number' => $grandprize['numbers'],
            'member_id' => $grandprize['member_id'],
            'prize_id' => '1'
        ));

        $this->db->select('member_id');
        $this->db->from('lucky_draw');

        // $rows = $this->db->get();

        // $duplicate = $rows->result_array();
        $second = $this->db->get();
        foreach ($second->result_array() as $duplicate)
            {
                $dup[] = $duplicate['member_id'];
            }
        $this->db->select('member_id, numbers');
        $this->db->from('winnings');
        $this->db->where_not_in('member_id',$dup);
        $this->db->order_by('rand()');
        $this->db->limit(1);

        $final = $this->db->get();

        foreach ($final->result_array() as $final_entry)
            {
                $mem[] = $final_entry['member_id'];
                $nums[] = $final_entry['numbers'];
            }

        $this->db->insert('lucky_draw', array(
            'winning_number' => $nums[0],
            'member_id' => $mem[0],
            'prize_id' => '2'
        ));

        $this->db->select('member_id');
        $this->db->from('lucky_draw');

        // $rows = $this->db->get();

        // $duplicate = $rows->result_array();
        $second2 = $this->db->get();

        foreach ($second2->result_array() as $duplicate)
            {
                $dup2[] = $duplicate['member_id'];
            }
        $this->db->select('member_id, numbers');
        $this->db->from('winnings');
        $this->db->where_not_in('member_id',$dup2);
        $this->db->order_by('rand()');
        $this->db->limit(1);

        $final2 = $this->db->get();

        foreach ($final2->result_array() as $final_entry)
            {
                $mem[] = $final_entry['member_id'];
                $nums[] = $final_entry['numbers'];
            }

        $this->db->insert('lucky_draw', array(
            'winning_number' => $nums[1],
            'member_id' => $mem[1],
            'prize_id' => '3'
        ));

        $this->db->select('member_id');
        $this->db->from('lucky_draw');

        // $rows = $this->db->get();

        // $duplicate = $rows->result_array();
        $third = $this->db->get();
        foreach ($third->result_array() as $duplicate)
            {
                $dup3[] = $duplicate['member_id'];
            }
        $this->db->select('member_id, numbers');
        $this->db->from('winnings');
        $this->db->where_not_in('member_id',$dup3);
        $this->db->order_by('rand()');
        $this->db->limit(1);

        $final3 = $this->db->get();

        foreach ($final3->result_array() as $final_entry)
            {
                $mem[] = $final_entry['member_id'];
                $nums[] = $final_entry['numbers'];
            }

        $this->db->insert('lucky_draw', array(
            'winning_number' => $nums[2],
            'member_id' => $mem[2],
            'prize_id' => '4'
        ));

        $this->db->select('member_id');
        $this->db->from('lucky_draw');

        // $rows = $this->db->get();

        // $duplicate = $rows->result_array();
        $third2 = $this->db->get();
        foreach ($third2->result_array() as $duplicate)
            {
                $dup4[] = $duplicate['member_id'];
            }
        $this->db->select('member_id, numbers');
        $this->db->from('winnings');
        $this->db->where_not_in('member_id',$dup4);
        $this->db->order_by('rand()');
        $this->db->limit(1);

        $final4 = $this->db->get();

        foreach ($final4->result_array() as $final_entry)
            {
                $mem[] = $final_entry['member_id'];
                $nums[] = $final_entry['numbers'];
            }

        $this->db->insert('lucky_draw', array(
            'winning_number' => $nums[3],
            'member_id' => $mem[3],
            'prize_id' => '5'
        ));

        $this->db->select('member_id');
        $this->db->from('lucky_draw');

        // $rows = $this->db->get();

        // $duplicate = $rows->result_array();
        $third3 = $this->db->get();
        foreach ($third3->result_array() as $duplicate)
            {
                $dup5[] = $duplicate['member_id'];
            }
        $this->db->select('member_id, numbers');
        $this->db->from('winnings');
        $this->db->where_not_in('member_id',$dup5);
        $this->db->order_by('rand()');
        $this->db->limit(1);

        $final5 = $this->db->get();

        foreach ($final5->result_array() as $final_entry)
            {
                $mem[] = $final_entry['member_id'];
                $nums[] = $final_entry['numbers'];
            }

        $this->db->insert('lucky_draw', array(
            'winning_number' => $nums[4],
            'member_id' => $mem[4],
            'prize_id' => '6'
        ));

    }
    
    function delete_draw () {
        $this->db->from('lucky_draw'); 
        $this->db->truncate();
    }
}


/* End of file candidate_model.php */
/* Location: ./application/account/models/candidate_model.php */