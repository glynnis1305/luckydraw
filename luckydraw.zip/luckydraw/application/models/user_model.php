<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class user_model extends CI_Model {
	public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();

        $CI =& get_instance();
        $CI->load->model(array(
        	'account/account_model',
        	'account/account_details_model',
        	'account/rel_account_role_model',
        	'sys_config_model'
        ));
		
		$this->account_model = $CI->account_model;
        $this->account_details_model = $CI->account_details_model;
        $this->rel_account_role_model = $CI->rel_account_role_model;
        $this->sys_config_model = $CI->sys_config_model;
    }

	function create_user ($a3m_data) {
		$user_id = $this->account_model->create($a3m_data['email'], $a3m_data['email'], $a3m_data['password']);
		$this->account_details_model->update($user_id);

		$a3m_details_data = array(
			'division_id' => !empty($a3m_data['division_id']) ? $a3m_data['division_id'] : null
		);

		$this->account_details_model->update($user_id, $a3m_details_data);

		return $user_id;
	}

	function update_user ($user_id, $a3m_data) {
		$a3m_details_data = array(
			'division_id' => !empty($a3m_data['division_id']) ? $a3m_data['division_id'] : null
		);

		$this->account_details_model->update($user_id, $a3m_details_data);

		if (!empty($a3m_data['password']) && !empty($a3m_data['confirm_password']) && $a3m_data['password'] == $a3m_data['confirm_password']) {
			$this->account_model->update_password($user_id, $a3m_data['password']);
		}
	}
}


/* End of file candidate_model.php */
/* Location: ./application/account/models/candidate_model.php */