<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2019-07-22 09:01:35 --> Severity: Notice  --> Undefined variable: color_code /Applications/AMPPS/www/luckydraw/application/views/manage_results.php 13
ERROR - 2019-07-22 09:01:35 --> 404 Page Not Found --> result/assets
ERROR - 2019-07-22 09:01:39 --> 404 Page Not Found --> user/assets
ERROR - 2019-07-22 09:01:41 --> 404 Page Not Found --> user/assets
ERROR - 2019-07-22 09:02:21 --> Severity: Notice  --> Undefined variable: color_code /Applications/AMPPS/www/luckydraw/application/views/manage_results.php 13
ERROR - 2019-07-22 09:02:21 --> 404 Page Not Found --> result/assets
ERROR - 2019-07-22 09:02:23 --> 404 Page Not Found --> user/assets
