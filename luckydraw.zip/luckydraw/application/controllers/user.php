<?php 
class User extends ET_Controller { 
	function __construct() { 
		parent::__construct();

		$this->load->model(array(
			'user_model'
		));
	}

	public function manage_user() {
		if (!$this->authorization->is_permitted('retrieve_consultants')) {
			show_404();
			die();
		}

		maintain_ssl();

		$header_data['website_title'] = 'lucky draw';
		$header_data['title'] = "User Manager";
		$header_data['page'] = 'user';
		$header_data['sub_page'] = 'manage_user';
		$header_data['pagetype'] = 'admin';

		$data['bcrn'] = array(
        'Home' => base_url(),
        'User' => base_url().'user',
        'User Manager' => base_url().'user/manage_user'
		);

		$data['title'] = "User Manager";

		$data['account'] = $this->account_model->get_by_id($this->session->userdata('account_id'));

		if ($this->session->flashdata('msg')) {
			$data['msg'] = $this->session->flashdata('msg');
		}

		$data['color_code'] = array('#c3c3c5', '#f5e34f', '#37d41d', '#a87112', '#2243a1', '#000000', '#ea0606');

		$data['datatable_ajax_url'] = 'user/manage_user_ajax';
		$data['datatable_columns'] = array(
			array(
				'data' => 'id',
				'name' => 'id',
				'title' => 'ID',
				'type' => 'num', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => false
			),
			array(
				'data' => 'username',
				'name' => 'username',
				'title' => 'Username',
				'type' => 'string', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => true
			),
			array(
				'data' => 'name',
				'name' => 'name',
				'title' => 'Division',
				'type' => 'string', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => true
			),
			array(
				'data' => 'email',
				'name' => 'email',
				'title' => 'Email',
				'type' => 'string', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => true
			),
			array(
				'data' => 'createdon',
				'name' => 'createdon',
				'title' => 'Reg On',
				'type' => 'date', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => false,
				'render' => 'return moment(data).isValid() ? moment(data).format(\'DD MMM YYYY\') : \'\';',
				'orderSequence' => 'desc'
			),
			array(
				'data' => 'account_id',
				'name' => 'account_id',
				'title' => 'Action',
				'type' => 'num', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => false,
				'searchable' => false,
				'render' => 'return \'<a class="btn btn-primary" href="'.base_url().'user/edit_user/\'+data+\'">Edit</a><a class="btn btn-danger" href="'.base_url().'user/delete_user/\'+data+\'">Delete</a>\';'
			)
		);
		// $data['datatable_createdrow'] = 'function ( row, data, index ) {'.
		// 	'console.log(row);console.log(data);'.
		// 	'if (data.tracking) {'.
  //           	'$(\'td\', row).eq(0).addClass(\'td-tracking-\'+data.tracking);'.
  //           '}'.
  //       '}';

		$data = isset($data) ? $data : NULL;
		$this->template_view('manage_user', $header_data, $data);
	}

	public function manage_user_ajax() {
		$params = $this->input->get();
		$json = array(
			'draw' => $params['draw'],
			'recordsTotal' => 0,
			'recordsFiltered' => 0,
			'data' => array()
		);

		// $is_admin = $this->authorization->is_admin();

		$this->db->from('a3m_account AS a3ma');
		$this->db->join(
			'a3m_rel_account_role AS a3mrar',
			'a3mrar.account_id = a3ma.id',
			'LEFT'
		);
		$query = $this->db->get();
		$json['recordsTotal'] = $query->num_rows();

		$this->db->start_cache();
		$this->db->select(
			'a3ma.*, a3mad.*, duser.*'
			, false
		);
		$this->db->from('a3m_account AS a3ma');
		$this->db->join(
			'a3m_account_details AS a3mad',
			'a3mad.account_id = a3ma.id',
			'LEFT'
		);
		
		$this->db->join(
			'division AS duser',
			'duser.id = a3mad.division_id',
			'LEFT'
		);
		$this->db->join(
			'a3m_rel_account_role AS a3mrar',
			'a3mrar.account_id = a3ma.id',
			'LEFT'
		);

		$search_clue = '';
		foreach ($params['columns'] as $index => $col) {
			if ($col['search']['value'] != '') {
				
			}
			else {
				if ($col['searchable'] == 'true' && $params['search']['value'] != '') {
					if (!empty($search_clue))	$search_clue .= " OR ";
					// $search_clue .= "{$col['name']} LIKE '%{$params['search']['value']}%'";
					if (in_array($col['name'], array('fullname', 'mobile'))) {
						$search_clue .= "a3mad.name LIKE '%{$params['search']['value']}%'";
					}
					else {
						$search_clue .= "a3ma.{$col['name']} LIKE '%{$params['search']['value']}%'";
					}
				}
			}
		}

		if (!empty($search_clue))
			$this->db->where("($search_clue)", null, false);

		$this->db->where("deletedon IS NULL", null, false);

		$this->db->stop_cache();
		$json['recordsFiltered'] = $this->db->count_all_results();
		// echo $this->db->last_query();

		if (count($params['order']) > 0) {
			foreach ($params['order'] as $order) {
				$order_col = $params['columns'][$order['column']]['name'];
				// $this->db->order_by("{$order_col}", $order['dir']);
				if (in_array($order_col, array('fullname', 'dateofbirth'))) {
					$this->db->order_by("a3mad.{$order_col}", $order['dir']);
				}
				else {
					$this->db->order_by("a3ma.{$order_col}", $order['dir']);
				}
			}
		}

		// if ($params['order'][0]['column'] != 1)
		$this->db->limit($params['length'], $params['start']);
		$query = $this->db->get();
		// echo $this->db->last_query();
		if ($query->num_rows() > 0) {
			$json['data'] = $query->result_array();
		}

		$this->db->flush_cache();

		echo json_encode($json);
	}

	public function create_users () {
		if (!$this->authorization->is_permitted('create_users')) {
			show_404();
			die();
		}

		$header_data['meta_title'] = "";
		$header_data['meta_description'] = '';
		$header_data['meta_keyword'] = '';

		maintain_ssl();

		$header_data['website_title'] = 'OMG';
		$header_data['title'] = "Create Users";
		$header_data['page'] = 'user';
		$header_data['sub_page'] = 'manage_user';
		$data['bcrn'] = array(
        'Home' => base_url(),
        'User' => base_url().'user',
        'User Manager' => base_url().'user/manage_user',
        'Create Users' => base_url().'user/create_users'
		);

		$data['account_id'] = $this->session->userdata('account_id');

		if ($this->input->post()) {
			$a3m_data = $this->input->post();

			$a3m_data['added_by'] = $this->session->userdata('account_id');
			$a3m_data['created_on'] = date('Y-m-d H:i:s');

			$user_id = $this->user_model->create_user($a3m_data);
			$this->audit_log_model->create_log('create_users', 'User account created. (ID: '.$user_id.')', $this->session->userdata('account_id'));

			$this->session->set_flashdata('msg', 'Data Added.');
			redirect('user/edit_user/'.$user_id);
		}

		$data['action'] = "add";

		$data = isset($data) ? $data : NULL;
		$this->template_view('create_user', $header_data, $data);
	}

	public function edit_user ($user_id) {
		if (!$this->authorization->is_permitted('update_users')) {
			show_404();
			die();
		}

		$header_data['meta_title'] = "";
		$header_data['meta_description'] = '';
		$header_data['meta_keyword'] = '';

		maintain_ssl();

		$header_data['website_title'] = 'OMG';
		$header_data['title'] = "Edit Admin";
		$header_data['page'] = 'user';
		$header_data['sub_page'] = 'manage_user';
		$data['bcrn'] = array(
        'Home' => base_url(),
        'User' => base_url().'user',
        'Admin Manager' => base_url().'user/manage_user',
        'Edit Admin' => base_url().'user/edit_user/'.$user_id
		);

		$data['account_id'] = $this->session->userdata('account_id');
		$data['user_id'] = $user_id;

		if ($this->session->flashdata('msg')) {
			$data['msg'] = $this->session->flashdata('msg');
		}

		if ($this->input->post()) {
			$a3m_data = $this->input->post();

			$a3m_data['edited_by'] = $this->session->userdata('account_id');
			$a3m_data['edited_on'] = date('Y-m-d H:i:s');

			$this->user_model->update_user($user_id, $a3m_data);
			$this->audit_log_model->create_log('update_user', 'User\'s profile updated. (ID: '.$user_id.')', $this->session->userdata('account_id'));
			
			$this->session->set_flashdata('msg', 'Data Updated.');
			redirect('user/edit_user/'.$user_id);
		}

		$data['action'] = "edit";

		$data['a3m_data'] = array();
		$this->db->select(
			'a3ma.*, a3mad.*, duser.*'
		);
		$this->db->from('a3m_account AS a3ma');
		$this->db->join(
			'a3m_account_details AS a3mad',
			'a3mad.account_id = a3ma.id',
			'LEFT'
		);
		$this->db->join(
			'division AS duser',
			'duser.id = a3mad.division_id',
			'LEFT'
		);
		$this->db->where('a3ma.id', $user_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			$data['a3m_data'] = $query->row_array();
		}

		$data = isset($data) ? $data : NULL;
		$this->template_view('create_user', $header_data, $data);
	}

	public function delete_consultant ($account_id) {
		$this->account_model->update_deleted_datetime($account_id);
		$this->audit_log_model->create_log('delete_user', 'User\'s account deleted. (ID: '.$account_id.')', $this->session->userdata('account_id'));
		$this->session->set_flashdata('msg', 'Data Deleted.');
		redirect('user/manage_user/'.$account_id);
	}

	public function audit_log() {

		maintain_ssl();

		$header_data['website_title'] = 'OMG';
		$header_data['title'] = "Audit Log";
		$header_data['page'] = 'user';
		$header_data['sub_page'] = 'audit_log';
		$header_data['pagetype'] = 'admin';

		$data['bcrn'] = array(
        'Home' => base_url(),
        'User' => base_url().'user',
        'Audit Log' => base_url().'user/audit_log'
		);

		$data['title'] = "Audit Log";

		$data['account'] = $this->account_model->get_by_id($this->session->userdata('account_id'));

		if ($this->session->flashdata('msg')) {
			$data['msg'] = $this->session->flashdata('msg');
		}

		$data['color_code'] = array('#c3c3c5', '#f5e34f', '#37d41d', '#a87112', '#2243a1', '#000000', '#ea0606');

		$data['datatable_ajax_url'] = 'user/manage_log_ajax';
		$data['datatable_columns'] = array(
			array(
				'data' => 'id',
				'name' => 'id',
				'title' => 'ID',
				'type' => 'num', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => false
			),
			array(
				'data' => 'account_id',
				'name' => 'account_id',
				'title' => 'Account ID',
				'type' => 'num', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => false
			),
			array(
				'data' => 'datetime',
				'name' => 'datetime',
				'title' => 'Date',
				'type' => 'datetime', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => false
			),
			array(
				'data' => 'activity',
				'name' => 'activity',
				'title' => 'Activity',
				'type' => 'string', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => true
			)
		);
		// $data['datatable_createdrow'] = 'function ( row, data, index ) {'.
		// 	'console.log(row);console.log(data);'.
		// 	'if (data.tracking) {'.
  //           	'$(\'td\', row).eq(0).addClass(\'td-tracking-\'+data.tracking);'.
  //           '}'.
  //       '}';

		$data = isset($data) ? $data : NULL;
		$this->template_view('audit_log', $header_data, $data);
	}

	public function manage_log_ajax() {
		$params = $this->input->get();
		$json = array(
			'draw' => $params['draw'],
			'recordsTotal' => 0,
			'recordsFiltered' => 0,
			'data' => array()
		);

		// $is_admin = $this->authorization->is_admin();

		$query = $this->db->get('ss_audit_log');
		$json['recordsTotal'] = $query->num_rows();

		$this->db->start_cache();
		$this->db->from('ss_audit_log');

		$search_clue = '';
		foreach ($params['columns'] as $index => $col) {
			if ($col['search']['value'] != '') {
				// if (in_array($index, array(1))) {
				// 	$this->db->where("p.{$col['name']} LIKE '%{$col['search']['value']}%'", null, false);
				// }
				// else if ($index == 2) {
				// 	$col['search']['value'] = explode(',', $col['search']['value']);
				// 	$in_val = '';
				// 	foreach ($col['search']['value'] as $val_row) {
				// 		if (!empty($in_val))	$in_val .= ",";
				// 		$in_val .= "'{$val_row}'";
				// 	}
				// 	$this->db->where("p.{$col['name']} IN ({$in_val})", null, false);
				// }
				// else if ($index == 10) {
				// 	$val = json_decode($col['search']['value'], true);
					
				// 	$clue = '';
				// 	if (!empty($val['start_date']) && $val['start_date'] != '0000-00-00') {
				// 		$start_date = date('Y-m-d', strtotime($val['start_date'])).' 00:00:00';
				// 		$clue .= "p.{$col['name']} >= '{$start_date}'";
				// 	}
				// 	if (!empty($val['end_date']) && $val['end_date'] != '0000-00-00') {
				// 		$end_date = date('Y-m-d', strtotime($val['end_date'])).' 23:59:59';
				// 		if (!empty($clue))	$clue .= " AND ";
				// 		$clue .= "p.{$col['name']} <= '{$end_date}'";
				// 	}
				// 	$this->db->where("($clue)", null, false);
				// }
			}
			else {
				if ($col['searchable'] == 'true' && $params['search']['value'] != '') {
					if (!empty($search_clue))	$search_clue .= " OR ";
					$search_clue .= "{$col['name']} LIKE '%{$params['search']['value']}%'";
					// if (in_array($col['name'], array('fullname'))) {
					// 	$search_clue .= "a3mad_candidate.{$col['name']} LIKE '%{$params['search']['value']}%'";
					// }
					// else if (in_array($col['name'], array('job_title'))) {
					// 	$search_clue .= "ssj.title LIKE '%{$params['search']['value']}%'";
					// }
					// else if (in_array($col['name'], array('consultant_username'))) {
					// 	$search_clue .= "a3ma_consultant.username LIKE '%{$params['search']['value']}%'";
					// }
					// else {
					// 	$search_clue .= "ssja.{$col['name']} LIKE '%{$params['search']['value']}%'";
					// }
				}
			}
		}

		if (!empty($search_clue))
			$this->db->where("($search_clue)", null, false);

		$this->db->stop_cache();
		$json['recordsFiltered'] = $this->db->count_all_results();
		// echo $this->db->last_query();

		if (count($params['order']) > 0) {
			foreach ($params['order'] as $order) {
				$order_col = $params['columns'][$order['column']]['name'];
				$this->db->order_by("{$order_col}", $order['dir']);
				// if (in_array($order_col, array('fullname'))) {
				// 	$this->db->order_by("a3mad_candidate.{$order_col}", $order['dir']);
				// }
				// else if (in_array($order_col, array('job_title'))) {
				// 	$this->db->order_by("ssj.title", $order['dir']);
				// }
				// else if (in_array($order_col, array('consultant_username'))) {
				// 	$this->db->order_by("a3ma_consultant.username", $order['dir']);
				// }
				// else {
				// 	$this->db->order_by("ssja.{$order_col}", $order['dir']);
				// }
			}
		}

		// if ($params['order'][0]['column'] != 1)
		$this->db->limit($params['length'], $params['start']);
		$query = $this->db->get();
		// echo $this->db->last_query();
		if ($query->num_rows() > 0) {
			$json['data'] = $query->result_array();

			// if ($params['order'][0]['column'] == 1) {
			// 	$results = $query->result_array();
			// 	$json['data'] = $this->category_recursive_sort($results, true);
			// }
		}

		$this->db->flush_cache();

		echo json_encode($json);
	}
}
?>