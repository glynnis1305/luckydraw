<?php 
class Login extends CI_Controller { 
	function __construct() { 
		parent::__construct();
		$this->load->helper('url');
		//$this->load->model('loadmodel');
		// Load the necessary stuff...
		$this->load->library('session');
		$this->load->config('account/account');
		$this->load->library(array('account/authentication', 'account/authorization', 'account/recaptcha', 'form_validation', 'gravatar'));
		$this->load->model(array('account/account_model'));
		$this->load->language(array('account/sign_in', 'account/connect_third_party'));
		$this->load->model(array('account/account_model', 'account/account_details_model', 'account/acl_role_model', 'account/rel_account_permission_model','account/rel_account_role_model', 'account/rel_role_permission_model'));
		// $this->load->language(array('general', 'account/account_profile'));
		$this->load->helper(array('language', 'account/ssl', 'url', 'photo'));
	}

	public function index() {
		// $this->load->helper('url');
		// redirect('management');

		maintain_ssl();
		if ($this->authentication->is_signed_in()) {
			redirect('management');
		}

		$data['website_title'] = 'lucky draw';
		$data['title'] = "Login";

		if ($this->input->post()) {
			if ( ! $user = $this->account_model->get_by_username_email($this->input->post('sign_in_username_email', TRUE)))
			{
				// Username / email doesn't exist
				$data['error_msg'] = 'Username/Email does not exist.';
			}
			else
			{
				// Either don't need to pass recaptcha or just passed recaptcha
				// if ( ! ($recaptcha_pass === TRUE || $recaptcha_result === TRUE) && $this->config->item("sign_in_recaptcha_enabled") === TRUE)
				// {
				// 	$data['sign_in_recaptcha_error'] = $this->input->post('recaptcha_response_field') ? lang('sign_in_recaptcha_incorrect') : lang('sign_in_recaptcha_required');
				// }
				// else
				// {
					// Check password
					if ( ! $this->authentication->check_password($user->password, $this->input->post('sign_in_password', TRUE)))
					{
						// Increment sign in failed attempts
						$this->session->set_userdata('sign_in_failed_attempts', (int)$this->session->userdata('sign_in_failed_attempts') + 1);

						$data['error_msg'] = 'Incorrect username/password combination.';
					}
					else
					{
						// Clear sign in fail counter
						$this->session->unset_userdata('sign_in_failed_attempts');
						$this->session->set_userdata('fair_id', $this->input->post('fair_id'));
						// Run sign in routine
						$this->authentication->sign_in($user->id, $this->input->post('sign_in_remember', TRUE));
					}
				// }
			}
		}


		$this->load->view('login', $data);
	}

}

?>