<?php 
class Management extends ET_Controller { 
	function __construct() { 
		parent::__construct();

		$this->load->model(array(
			'luckydraw_model'
		));
	}

	public function index() {

		// maintain_ssl();

		$header_data['website_title'] = 'Lucky Draw';
		$header_data['title'] = "Dashboard";
		$header_data['page'] = 'dashboard';

		if ($this->input->post()) {
			$result_id = $this->luckydraw_model->prize($data);
	        
			$this->session->set_flashdata('msg', 'Lucky draw results have been picked.');
			// redirect('management/'.$result_id);
			redirect('result/manage_result');
			}

		$data = isset($data) ? $data : NULL;
		$this->template_view('dashboard', $header_data, $data);
	}

	public function logout() {
		// Redirect signed out users to homepage
		if ( ! $this->authentication->is_signed_in()) redirect('');

		$this->authentication->sign_out();

		if ( ! $this->config->item("sign_out_view_enabled")) redirects('');

		redirect('');
	}

	public function delete_draw() {
		maintain_ssl();

		$this->luckydraw_model->delete_draw();
		$this->session->set_flashdata('msg', 'Data Deleted.');
		redirect('management');
	}
	

	
}

?>