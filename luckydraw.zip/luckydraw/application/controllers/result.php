<?php 
class Result extends ET_Controller { 
	function __construct() { 
		parent::__construct();

		$this->load->database();
		
	}

	public function manage_result() {

		maintain_ssl();

		$header_data['website_title'] = 'Lucky Draw';
		$header_data['title'] = "Result Manager";
		$header_data['page'] = 'result';
		$header_data['sub_page'] = 'manage_result';
		$header_data['pagetype'] = 'admin';

		$data['bcrn'] = array(
        'Home' => base_url(),
        'Result Manager' => base_url().'result/manage_results'
		);

		$data['title'] = "Result Manager";

		$data['account'] = $this->account_model->get_by_id($this->session->userdata('account_id'));

		if ($this->session->flashdata('msg')) {
			$data['msg'] = $this->session->flashdata('msg');
		}

		$data['datatable_ajax_url'] = 'result/manage_results_ajax';
		$data['datatable_columns'] = array(
			array(
				'data' => 'id',
				'name' => 'id',
				'title' => 'ID',
				'type' => 'num', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => false
			),
			array(
				'data' => 'prize_name',
				'name' => 'prize_name',
				'title' => 'Prize',
				'type' => 'string', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => true,
			),
			array(
				'data' => 'name',
				'name' => 'name',
				'title' => 'Winner Name',
				'type' => 'string', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => true,
			),
			array(
				'data' => 'winning_number',
				'name' => 'winning_number',
				'title' => 'Winning Number',
				'type' => 'num', // date, num, num-fmt, html-num, html-num-fmt, html, string
				'orderable' => true,
				'searchable' => true,
			)
			
		);
		// <a target="_blank;" href="'.base_url().'customer/regenerate_cert/\'+data+\'" class="btn btn-default btn-sm btn-icon icon-right"><i class="entypo-pencil"></i>Regenerate Cert</a>

		$data = isset($data) ? $data : NULL;
		$this->template_view('manage_results', $header_data, $data);
	}

	public function manage_results_ajax() {
		$params = $this->input->get();
		$json = array(
			'draw' => $params['draw'],
			'recordsTotal' => 0,
			'recordsFiltered' => 0,
			'data' => array()
		);

		// $is_admin = $this->authorization->is_admin();

		$this->db->from('lucky_draw AS draw');
		$this->db->join(
			'member AS mem',
			'draw.member_id = mem.id',
			'LEFT'
		);
		$this->db->join(
			'prize AS pri',
			'draw.prize_id = pri.id',
			'LEFT'
		);
		$query = $this->db->get();
		$json['recordsTotal'] = $query->num_rows();

		// var_dump($query);
		//var_dump($data['prize_name']);

		$this->db->start_cache();
		$this->db->select(
			'draw.id, mem.name, draw.winning_number, pri.prize_name'
			, false
		);
		$this->db->from('lucky_draw AS draw');
		$this->db->join(
			'member AS mem',
			'draw.member_id = mem.id',
			'LEFT'
		);
		$this->db->join(
			'prize AS pri',
			'draw.prize_id = pri.id',
			'LEFT'
		);

		$search_clue = '';
		foreach ($params['columns'] as $index => $col) {
			if ($col['search']['value'] != '') {
				
			}
			else {
				if ($col['searchable'] == 'true' && $params['search']['value'] != '') {
					if (!empty($search_clue))	$search_clue .= " OR ";
					$search_clue .= "{$col['name']} LIKE '%{$params['search']['value']}%'";
					
				}
			}
		}

		if (!empty($search_clue))
			$this->db->where("($search_clue)", null, false);

		$this->db->stop_cache();
		$json['recordsFiltered'] = $this->db->count_all_results();
		// echo $this->db->last_query();

		if (count($params['order']) > 0) {
			foreach ($params['order'] as $order) {
				$order_col = $params['columns'][$order['column']]['name'];
				$this->db->order_by("{$order_col}", $order['dir']);
				
			}
		}

		// if ($params['order'][0]['column'] != 1)
		$this->db->limit($params['length'], $params['start']);
		$query = $this->db->get();
		// echo $this->db->last_query();
		if ($query->num_rows() > 0) {
			$json['data'] = $query->result_array();

			
		}

		$this->db->flush_cache();

		echo json_encode($json);
	}

	
}
?>