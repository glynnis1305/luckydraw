<?php 
class ET_Controller extends CI_Controller { 
	function __construct() { 
		parent::__construct();
		$this->load->helper('url');
		//$this->load->model('loadmodel');
		// Load the necessary stuff...

		// $controller =$this->uri->segment(1);
		// $method = $this->uri->segment(2);

		// $skip_session = false;
		// if ($controller == 'campaign' && ($method == 'process_campaign_cart_photo_ajax' || $method == 'send_to_fb_ajax')) {
		// 	$skip_session = true;
		// }

		// // var_dump($skip_session);

		// if (!$skip_session) {
		// 	$this->load->library('session');
		// }
		$this->load->library('session');

		$this->load->config('account/account');
		$this->load->library(array('account/authentication', 'account/authorization', 'account/recaptcha', 'form_validation', 'gravatar'));
		$this->load->model(array('account/account_model'));
		$this->load->language(array('account/sign_in', 'account/connect_third_party'));
		$this->load->model(array('account/account_model', 'account/account_details_model', 'account/acl_role_model', 'account/rel_account_permission_model','account/rel_account_role_model', 'account/rel_role_permission_model'));
		// $this->load->language(array('general', 'account/account_profile'));
		$this->load->helper(array('language', 'account/ssl', 'url', 'photo'));

		$this->load->library(array('session', 'form_validation', 'gravatar'));
		$this->load->helper(array('language', 'url', 'photo'));

		if (!$this->session->userdata('fair_id')) {
			$this->session->set_userdata('fair_id', '1');
		}
	}

	public function template_view($view, $headcontent = array(), $vars = array()) {
		maintain_ssl();
		if ($this->authentication->is_signed_in())
		{
			// Retrieve sign in user
			$headcontent['account'] = $this->account_model->get_by_id($this->session->userdata('account_id'));
			$headcontent['account_details'] = $this->account_details_model->get_by_account_id($this->session->userdata('account_id'));
			$all_account_roles = $this->rel_account_role_model->get();
			$admin_role = $this->acl_role_model->get_by_name('Admin');
			//var_dump($headcontent['account_details']);
			foreach( $all_account_roles as $acrole ) 
		      {
		        if( $acrole->account_id == $this->session->userdata('account_id') && $acrole->role_id == $admin_role->id ) 
		        {
		          $headcontent['is_admin'] = TRUE;
		        }
		      }
			
			// Retrieve user's gravatar if available
			$headcontent['gravatar'] = $this->gravatar->get_gravatar( $headcontent['account']->email );
		}
		else {
			redirect('login');
		}

		if(!empty($headcontent['bcrn']))
		{
			$headcontent['bcrn'] = $headcontent['bcrn'];
		} else {
			$headcontent['bcrn'] = '';
		}

		// $vars = array_merge($vars, $headcontent);
		$vars['header_data'] = $headcontent;
		
		// $this->load->view('etheader', $headcontent);
		$this->load->view($view,$vars); //if Returning views as data as string have to addin true ($view, $vars, true)
		// $this->load->view('etfooter', $headcontent);

		
	  }

	 public function force_logout ($msg) {
	 	$this->session->set_flashdata('logout_error', $msg);

		if ( ! $this->authentication->is_signed_in()) redirect('');

		$this->authentication->sign_out();

		if ( ! $this->config->item("sign_out_view_enabled")) redirects('');

		redirect('');
	 }



}