<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Facebook API
|--------------------------------------------------------------------------
|
| Facebook Applications - http://www.facebook.com/developers/createapp.php
|
*/
$config['facebook_app_id'] = "";
$config['facebook_secret'] = "";


/* End of file facebook.php */
/* Location: ./application/account/config/facebook.php */