<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Twitter API
|--------------------------------------------------------------------------
|
| Twitter Applications - http://dev.twitter.com/apps
|
*/
$config['twitter_consumer_key'] 	= "";
$config['twitter_consumer_secret'] 	= "";


/* End of file twitter.php */
/* Location: ./application/account/config/twitter.php */