<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| reCAPTCHA
|--------------------------------------------------------------------------
|
| reCAPTCHA PHP Library - http://recaptcha.net/plugins/php/
|
| recaptcha_theme	'red' | 'white' | 'blackglass' | 'clean' | 'custom'
*/
$config['recaptcha_public_key'] 	= "";
$config['recaptcha_private_key'] 	= "";
$config['recaptcha_theme'] 			= "white";


/* End of file recaptcha.php */
/* Location: ./application/account/config/recaptcha.php */